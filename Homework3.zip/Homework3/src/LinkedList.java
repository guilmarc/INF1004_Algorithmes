/**
 * Created by guilmarc on 2016-03-28.
 */
public class LinkedList<T> {

    private Link first;


    public LinkedList() {
        this.first = null;
    }

    public boolean isEmpty() {
        return (this.first == null);
    }

    public void insertFirst(T data){

        //Link newLink = new Link(data);
        //newLink.setNext(first); // newLink --> old first
        //this.first = newLink;
    }





}
